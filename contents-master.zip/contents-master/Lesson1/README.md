# Setting up IPython notebook and thirdparty Python libraries
